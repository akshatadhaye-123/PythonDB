import mysql.connector

con=mysql.connector.connect(host='localhost',user='root',password='akshu8459',database='bookstoredb')
curs=con.cursor()

code=int(input('Enter Bookcode: '))
review=input('Enter Your review : ')

try:
    curs.execute("update book set review='%s' Where Bookcode=%d" %(review,code))
    con.commit()
    print("Updation is Successfull ")
except:
    print('Updation is not successfull ')
