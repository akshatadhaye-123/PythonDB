import mysql.connector 

con=mysql.connector.connect(host='localhost',user='root',password='akshu8459',database='bookstoredb')
curs=con.cursor

curs.execute("select * from books ")
data=curs.fetchall()
print(data)

con.close()