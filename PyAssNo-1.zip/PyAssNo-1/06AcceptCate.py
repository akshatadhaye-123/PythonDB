import mysql.connector 
con=mysql.connector.connect(host='localhost',user='root',password='akshu8459',database='bookstoredb')
curs=con.cursor()

cate=(input('Enter category  :'))
curs.execute("select booknm,author,price,edition from books where category='%s' " %cate)
rec=curs.fetchone()
print(rec)

con.close()