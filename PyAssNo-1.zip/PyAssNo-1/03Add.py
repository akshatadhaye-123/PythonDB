import mysql.connector as mycon

con=mycon.connect(host='localhost',user='root',password='akshu8459',database='bookstoredb')
curs=con.cursor()

code=int(input('Enter bookcode :'))
nm=input('Enter bookname :')
cate=input('Enter category :')
auth=input('Enter author :')
edi=int (input('Enter edition :'))
pri=float(input('Enter price :'))

curs.execute("insert into books values(%d,'%s','%s','%s',%d,%.2f)" %(code,nm,cate,auth,edi,pri))
con.commit()

print('New books added successfully')
