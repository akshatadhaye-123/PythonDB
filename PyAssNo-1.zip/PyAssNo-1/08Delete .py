import mysql.connector

con=mysql.connector.connect(host='localhost',user='root',password='akshu8459',database='bookstoredb')
curs=con.cursor()

try:
    code=int(input('Enter Bookcode to delete : '))
    curs.execute("select * from books where bookcode=%d" %(code))
    data=curs.fetchone()
    print(data)
    n=input('Do you want to delete(Yes/No)? ')
    if (n.upper()=='YES'):
        curs.execute("delete from books Where bookcode=%d" %(code))
        con.commit()
        print('Book Data deleted Successfully..')
    else:
        print('Book data does not exist..')
except:
     print('Error in deletion..')
con.close()
