import mysql.connector 

con=mysql.connector.connect(host='localhost',user='root',password='akshu8459',database='bookstoredb')
curs=con.cursor()

code=int(input("Enter bookcode :"))
curs.execute("select booknm,category,author,edition,price from books where bookcode=%d" %code)
data=curs.fetchone()



try:
    print('Name  : %s' %data[0])
    print('author : %s' %data[1])
    print('category : %s' %data[2])
    print('edition: %s' %data[3])
    print('price : %.2f' %data[4])
except:
    print('no found')
con.close()



