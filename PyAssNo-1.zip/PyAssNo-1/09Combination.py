import mysql.connector

con=mysql.connector.connect(host='localhost',user='root',password='akshu8459',database='bookstoredb')
curs=con.cursor()

auth=input('Enter author name : ')
cate=input('Enter category : ')
curs.execute("select booknm from books Where author='%s'and category='%s' " %(auth,cate))
data=curs.fetchone()
while data:
    print(data)
    data = curs.fetchone()

con.close()