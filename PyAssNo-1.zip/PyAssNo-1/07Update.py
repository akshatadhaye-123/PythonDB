import mysql.connector

con = mysql.connector.connect(host='localhost' , user='root' , password='akshu8459' , database='bookstoredb')
curs=con.cursor()

code = int(input("Enter Bookcode : "))
price = int(input("Enter price : "))

Booknm=input("Enter new Bookname : ")
Cate=input("Enter new Category : ")
Auth=input("Enter new Author : ")
Edi=input("Enter new Edition : ")
try:
    curs.execute("Update book set Bookname='%s' ,Category='%s', Author='%s' ,Price='%.2f',Edition='%d' where Bookcode=%d and Price=%.2f" %(Booknm,Cate,Auth,Edi,code,price))
    con.commit()
    print("Entery successfull..")
except:
    print("Book Does Not Exist")


